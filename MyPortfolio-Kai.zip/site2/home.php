<?php
 session_start();
 require 'db.php';

 if(!isset($_SESSION['user_id'])) {
   header("Location:login.php");
   exit();
 }
?>

<!DOCTYPE html>
<html lang="ru">
 <main>
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Security-Policy">
    <meta name="referrer" content="no-referrer-when-downgrade">
    <meta name="application-name" content="1x7KaiSite">
    <meta name="X-XSS-Protection" content="1; mode=block">
    <meta name="X-Content-Type-Options" content="nosniff">
      <title>My site</title>
      <link rel="stylesheet" href="styles.css">
      <link rel="icon" href="#">
  </head>
  <body>
    <header>
       <ul>
          <li><a href="#">Home</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="services.php">Services</a></li>
       </ul>
    </header>
      <nav><h2>Home</h2>
        <?php
          require 'db.php';
          session_start();
          
          if(isset($_SESSION['name'])) {
           $name = $_SESSION['name'];
           echo "Добро пожаловать, " . htmlspecialchars($name) . "!";
          } else {
             echo "Добро пожаловать, гость!";
            }
        ?>
      <p>Выйти из своего <a class="register-btn" href="logout.php">профиля</a></p>
      </nav>

      <div class="container">
         <h2 class="h2-container">Тут будет информация о самом сайте</h2>
         <p>Данный сайт существует под моим руководстовом, так как я и явлюсь его владельцем.</p>
         <p>Тут я лишь расскажу кратко, что зачем и почему этот сайт существует.</p>
         <p>Если вы хотите узнать <a class="text-container" href="about.php">подробности</a>, то переходите во вкладку "О нас".</p>
         <p>Если вы хотите заказать <a class="text-container" href="services.php">услугу</a> у меня, то перейдите во вкладку "Сервис".</p>
         <i>Чтобы чётко, кратко и понятно разъяснить для чего этот сайт: я просто повторяю знания и свои умения использовать HTML-разметку по памяти.</i>
      </div>
      <div class="commentr">
        <h2>Оставить комментарий: </h2>
          <form id="commentForm">
           <label for="name">Name: </label>
           <input type="text" id="name" name="name" placeholder="Введите своё имя.." required pattern="^[a-zA-Z0-9]*$">
           <label for="email">Email: </label>
           <input type="email" id="email" name="email" placeholder="Введите своё email.." required>
           <label for="text">Text: </label>
           <textarea rows="4" id="text" name="text" placeholder="Оставить свой комментарий" required></textarea>
           <button class="comment-btn" type="submit">Отправить</button>
         </form>

       <div class="comments" id="commentsContainer">
        <h3>Комментарии:</h3>
       </div>
      </div>

<script>
   const form = document.getElementById('commentForm');
   const commentsContainer = document.getElementById('commentsContainer');


   form.addEventListener('submit', (event) => {
     event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const text = document.getElementById('text').value;

    if (!name || !email || !text) {
      alert('Пожалуйста, заполните все поля');
      return;
    }

    const comment = document.createElement('div');
    comment.classList.add('comment');
    comment.innerHTML = `
    <p><strong>${name}</strong> (${email})</p>
    <p>${text}</p>
    `;

    commentsContainer.appendChild(comment);

   form.reset();
   });
</script>
    <footer>
       <p>&copy;2025 1x7Kai. All right reserved.</p>
    </footer>
   </main>
  </body>
</html>